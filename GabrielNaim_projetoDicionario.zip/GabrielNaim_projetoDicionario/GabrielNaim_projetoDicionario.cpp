#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <cstdlib>

struct Palavra {
	char palavra[100];
	int recorrencia;
	struct Palavra *prox;
};

int main(){
	
	int menu(struct Palavra *inicio);
	int textoExiste(int num);
	int imprimirLista();
	char *escolherTexto(struct Palavra* inicio);
	int insereEncadeada(struct Palavra *inicio, char palavra_texto[]);
	int printEncadeada(struct Palavra *inicio);
	int dividirTexto(struct Palavra *inicio, char caminhoArquivo[]);
	int arquivoDicionario(struct Palavra *inicio, char caminhoArquivo[]);

	struct Palavra *inicio;
	inicio = (struct Palavra*) malloc(sizeof(struct Palavra));
	inicio->prox = NULL;
		
	menu(inicio);
	
	return 0;
	
}

// Verifica se o texto passado por parametro (numero inteiro) existe dentro
// da pasta "Textos". Se existe, retorna "1", se nao existe, retorna "0". 
int textoExiste(int num){
	
	int q = 0;
	
	char numero[2];
	
	if(num<10){
		sprintf(numero, "0%d", num);
	} else {
		sprintf(numero, "%d", num);
	}
	
	char arquivo[13] = { 'T', 'e', 'x', 't', 'o', 's', '\\', numero[0], numero[1], '.', 't', 'x', 't'};
	
	FILE *arq_texto;
	
	arq_texto = fopen(arquivo, "r");
	
	if(arq_texto != NULL){
		q = 1;
	}
	
	fclose(arq_texto);
	
	return q;
	
}

int arquivoDicionario(struct Palavra *inicio, char caminhoArquivo[]){
	struct Palavra *pont;
	pont = (struct Palavra*) malloc(sizeof(struct Palavra));
	pont = inicio;
	
	FILE *arq_dicionario;
	
	char arquivo[19] = {'D', 'i', 'c', 'i', 'o', 'n', 'a', 'r', 'i', 'o', 's', '\\', caminhoArquivo[7], caminhoArquivo[8], '.', 't', 'x', 't'};
	
	arq_dicionario = fopen(arquivo, "w");
	
	fprintf(arq_dicionario, "Palavra / Recorrencia\n");
	while(pont->prox != NULL){
		pont = pont->prox;
		fprintf(arq_dicionario, "%s - %d\n", pont->palavra, pont->recorrencia);
	}
		
	fclose(arq_dicionario);
	
	return 0;
	
}

// Printa a listagem de textos disponiveis na tela. A listagem eh atualizada automaticamente
// a partir de todos os arquivos textos disponiveis presentes na pasta "Textos".
// O titulo exibido na listagem eh feito a partir da primeira linha de cada
// arquivo de texto. 
int imprimirLista(){
	
	system("cls");
	
	int i = 1;
	
	char numero[2];
	
	if(textoExiste(i) == 0){
		printf("\n     Nao ha textos disponiveis. \n\n");
	} else if(textoExiste(i) == 1){
		printf("\n\n               -Textos Disponiveis- \n\n");
		do{
			if(i<10){
				sprintf(numero, "0%d", i);
			} else {
				sprintf(numero, "%d", i);
			}
			char texto[200];
			FILE *arq_texto;
			char arquivo[13] = { 'T', 'e', 'x', 't', 'o', 's', '\\', numero[0], numero[1], '.', 't', 'x', 't'};
			arq_texto = fopen(arquivo, "r");
			fgets(texto, 200, arq_texto);
			printf("    (%s) ", numero);
			printf("%s\n", texto);
			i += 1;
			fclose(arq_texto);
		} while(textoExiste(i) == 1);
		printf("\n");
	}
	return 0;
}

// Insere palavras na lista encadeada. Se a palavra ja existe na lista, sua recorrencia
// eh acrescida e a palavra nao eh inserida novamente. A palavra eh passada pelo parametro.
int insereEncadeada(struct Palavra *inicio, char palavra_texto[]){
	int achou = 0;
	struct Palavra *pont;
	pont = (struct Palavra*) malloc(sizeof(struct Palavra));
	pont = inicio;
	
	if(inicio->prox == NULL){
		struct Palavra *novo;
		novo = (struct Palavra*) malloc(sizeof(struct Palavra));
		strcpy(novo->palavra, palavra_texto);
		novo->recorrencia = 1;
		novo->prox = NULL;
		inicio->prox = novo;
	} else {
		while(pont->prox != NULL && achou == 0){
			pont = pont->prox;
			if(strcmp(pont->palavra, palavra_texto) == 0){
				pont->recorrencia += 1;
				achou += 1;
			}
		}
	} if(pont->prox == NULL && achou == 0){
		struct Palavra *novo;
		novo = (struct Palavra*) malloc(sizeof(struct Palavra));
		strcpy(novo->palavra, palavra_texto);
		novo->recorrencia = 1;
		novo->prox = NULL;
		pont->prox = novo;
	}
		
	return 0;
}

// printa a lista encadeada atual na tela.
int printEncadeada(struct Palavra *inicio){
	if(inicio->prox == NULL){
		printf("A lista esta vazia.");
	} else {
		printf("  Palavra / Recorrencia\n");
		struct Palavra *pont;
		pont = (struct Palavra*) malloc(sizeof(struct Palavra));
		pont = inicio;
		while(pont->prox != NULL){
			pont = pont->prox;
			printf("  %s - %d\n", pont->palavra, pont->recorrencia);
		}
	}
	return 0;
}

// Pega o arquivo de texto escolhido (caminho passado por parametro) e divide suas
// palavras, retirando sinais, espa�os, quebras de linha etc. Cada palavra eh
// jogada na lista encadeada.
int dividirTexto(struct Palavra *inicio, char caminhoArquivo[]){
	
	int menu(struct Palavra *inicio);
	
	FILE *arq_texto;
	arq_texto = fopen(caminhoArquivo, "r");
	
	char titulo[100];
	char texto[200];
	
	char *palavra;
	
	fgets(titulo, 50, arq_texto);
	
	while(fgets(texto, 200, arq_texto) != NULL){
		palavra = strtok(texto, " ()[]!?,.\n:;");
		while(palavra != NULL){
			insereEncadeada(inicio, palavra);
    		palavra = strtok (NULL, " ()[]!?,.\n:;");
		}
	}
	
	fclose(arq_texto);
	
	arquivoDicionario(inicio, caminhoArquivo);
	
	printEncadeada(inicio);
	
	printf("\n\n");
	
	printf("  Um arquivo de dicionario do texto %c%c %s  foi criado na pasta 'Dicionarios'!", caminhoArquivo[7], caminhoArquivo[8], titulo);
	
	printf("\n\n");
	
	char resposta;
	printf("  Deseja continuar?\n");
	printf("  Resposta ('s'/'n'): ");
	scanf(" %c", &resposta);
	while(resposta != 's' && resposta != 'n'){
		
		system("cls");
		
		arq_texto = fopen(caminhoArquivo, "r");
		
		printf("\n\n");
		while(fgets(texto, 128, arq_texto) != NULL){
			printf("      %s", texto);
		}
		printf("\n\n");
		
		printf("\n");
		
		printf("Um arquivo de dicionario do texto %c%c %s  foi criado na pasta 'Dicionarios'!\n\n", caminhoArquivo[7], caminhoArquivo[8], titulo);
		
		printEncadeada(inicio);
		
		printf("\n");
		
		printf("  Resposta invalida.\n");
		printf("  Deseja continuar?\n");
		printf("  Resposta ('s'/'n'): ");
		scanf(" %c", &resposta);
		
	} if(resposta == 's'){
		inicio->prox = NULL;
		menu(inicio);
	} else if(resposta == 'n'){
		return 0;
	}
	
	return 0;
	
}

// Abre o texto escolhido escolhido pelo usuario. O texto escolhido eh printado na tela.
char *escolherTexto(struct Palavra *inicio){
	
	int menu(struct Palavra *inicio);
	
	system("cls");
	imprimirLista();
	
	char numero[2];
	
	printf("  Escolha um dos textos pelo seu codigo: ");
	scanf("%s", numero);
	printf("\n");
	
	char arquivoAux[14] = { 'T', 'e', 'x', 't', 'o', 's', '\\', numero[0], numero[1], '.', 't', 'x', 't'};
	
	char *caminhoArquivo;
	caminhoArquivo = (char*) malloc(sizeof(char)*13);

	for(int i = 0; i < 13; i++){
		caminhoArquivo[i] = arquivoAux[i];
	}
	
	FILE *arq_texto;
	arq_texto = fopen(caminhoArquivo, "r");
	
	char texto[128];
	
	while(arq_texto == NULL){
		
		system("cls");
		imprimirLista();
		
		printf("  Codigo nao existente.\n");
		printf("  Escolha um dos textos pelo seu codigo: ");
		scanf("%s", numero);
		
		char arquivoAux[14] = { 'T', 'e', 'x', 't', 'o', 's', '\\', numero[0], numero[1], '.', 't', 'x', 't'};
	
		char *caminhoArquivo;
		caminhoArquivo = (char*) malloc(sizeof(char)*13);
	
		for(int i = 0; i < 13; i++){
			caminhoArquivo[i] = arquivoAux[i];
		}
		
		arq_texto = fopen(caminhoArquivo, "r");
		
	}
	
	system("cls");
	printf("\n\n");
	
	while(fgets(texto, 128, arq_texto) != NULL){
		printf("      %s", texto);
	}
	
	fclose(arq_texto);
	
	printf("\n\n");
	
	char resposta;
	printf("\n  Deseja gerar um dicionario das palavras presentes nesse texto?\n");
	printf("  Resposta ('s'/'n'): ");
	scanf(" %c", &resposta);
	while(resposta != 's' && resposta != 'n'){
		
		system("cls");
		
		arq_texto = fopen(caminhoArquivo, "r");
		
		printf("\n\n");
		while(fgets(texto, 128, arq_texto) != NULL){
			printf("      %s", texto);
		}
		printf("\n\n");
		
		printf("  Resposta invalida.\n");
		printf("  Deseja gerar um dicionario das palavras presentes nesse texto?\n");
		printf("  Resposta ('s'/'n'): ");
		scanf(" %c", &resposta);
		
	} if(resposta == 's'){
		printf("\n\n");
		dividirTexto(inicio, caminhoArquivo);
		
	} else if(resposta == 'n'){
		system("cls");
		menu(inicio);
	}
	
	return caminhoArquivo;
	
}

// Inicia o programa.
int menu(struct Palavra *inicio){
	
	system("cls");
	
	char q;
	
	printf("\n\n");
	
	printf("'\n");
	printf("                                  |\\__/,|   (`\\\n");
	printf("                                  |_ _  |.--.) )\n");
	printf("                                  ( T   )      /\n");
	printf("                                 (((^_(((/(((_/\n\n");
	
	printf("  Nesse programa, voce verah uma listagem de textos disponiveis para criacao de um\n");
	printf("  dicionario a partir do texto escolhido. Nesse dicionario, serao listadas todas\n");
	printf("  as palavras presentes no texto e, ao lado, sua recorrencia no texto.\n");
	printf("  Voce podera gerar um arquivo .txt do dicionario criado e este arquivo sera\n");
	printf("  disponibilizado na pasta 'Dicionarios'\n\n");
	printf("  Para disponibilizar novos textos na listagem, basta acrescentar um novo texto em arquivo\n");
	printf("  .txt na pasta 'Textos'. A primeira linha do arquivo .txt sera seu titulo, que\n");
	printf("  aparecerah na listagem. O nome do novo arquivo .txt deverah ser um numero de\n");
	printf("  um digito, precedido de um zero (EX: 07) ou um numero de dois digitos.\n\n");
	
	printf("  Digite '1' e aperte 'enter' para prosseguir.\n");
	printf("\n  Resposta: ");
	scanf("%c", &q);
	if(q != '1'){
		
		system("cls");
		
		menu(inicio);
			
	} else if(q == '1'){
		imprimirLista();
		escolherTexto(inicio);
	}
	
	return 0;
}








